#ifndef _MAIN_MAZE_
#define _MAIN_MAZE_

using namespace std;  

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <iostream>
#include <sys/time.h>




void GUsage();
bool isInfoSet(int argc, char* argv[]);
void processError_lessargs(int argc, char* argv[]);

#endif
