#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <iostream>
#include <sys/time.h>
using namespace std;  


void GUsage();

int test1();
void PrintTestList(My570List *pList, int num_items);
int  RandomShuffle();
int RandomIndex(int);
int test2_linkunlink();
int test2_unlinkAll();
int test_prepend();
int test_FindObj();
int test_InsertBefore();
int test_InsertAfter();

