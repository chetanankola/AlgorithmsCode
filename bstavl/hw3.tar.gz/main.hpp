#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <iostream>
#include <sys/time.h>
using namespace std;  

void GUsage();
bool isDisplaySet(int argc, char* argv[]);
void processError_lessargs(int argc, char* argv[]);
